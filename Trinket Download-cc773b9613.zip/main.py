a=5
b=7

z= a + b

print (a +b)

print (a*b)

print (a/b)

print (b-a)

print(z)



list = [1,1,2,3,5,8,13,21]
print (sum(list))

l= [13.2, 7, 1, 19, 0]
print (sum(l))

